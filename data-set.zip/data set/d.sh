#!/bin/bash
PAGE_ID=$1
USER=$2
PASS=$3
wget "https://torc.cloudant.com/final_$PAGE_ID/_all_docs?include_docs=true" --user=$2 --password=$3 -O $PAGE_ID.json
